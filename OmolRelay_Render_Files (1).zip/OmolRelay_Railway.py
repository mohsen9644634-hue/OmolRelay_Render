from flask import Flask, request, jsonify
import requests
import os

app = Flask(__name__)

TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
LBANK_API_KEY = os.getenv('LBANK_API_KEY')
LBANK_API_SECRET = os.getenv('LBANK_API_SECRET')
RELAY_MODE = os.getenv('RELAY_MODE', 'test')

@app.route('/')
def home():
    return 'OmolRelay active and ready.'

@app.route('/ping')
def ping():
    return jsonify({'status': 'online', 'mode': RELAY_MODE})

@app.route('/order', methods=['POST'])
def order():
    data = request.get_json(force=True)
    if not data:
        return jsonify({'error': 'Invalid JSON'}), 400
    try:
        pair = data.get('pair', 'BTCUSDT')
        side = data.get('side', 'buy')
        amount = data.get('amount', 0.001)

        base_url = 'https://www.lbkex.co'
        endpoint = '/v1/order/create'

        headers = {
            'Content-Type': 'application/json',
            'X-API-KEY': LBANK_API_KEY,
            'X-API-SECRET': LBANK_API_SECRET
        }
        payload = {
            'symbol': pair,
            'side': side,
            'amount': amount,
            'type': 'market'
        }

        if RELAY_MODE != 'live':
            return jsonify({'status': 'demo-mode', 'payload': payload})

        resp = requests.post(base_url + endpoint, headers=headers, json=payload)
        return jsonify(resp.json())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
